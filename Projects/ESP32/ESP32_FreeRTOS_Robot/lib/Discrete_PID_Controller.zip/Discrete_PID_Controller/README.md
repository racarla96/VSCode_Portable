# Discrete PID Controller
A Discrete PID Library for cpp, including Arduino. Adapted from https://github.com/btill/zpid.
