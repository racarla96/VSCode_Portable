function testCallback(u, ~)
warning('off')
data = read(u,u.NumDatagramsAvailable,"string");
% jd = jsondecode(data.Data);
jd
end

